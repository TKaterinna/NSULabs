<!DOCTYPE html>
<head>
    <meta charset='utf-8'>
</head>
<title>Find</title>
<!-- выбор формы поиск телефона или партнера -->
<body>
    <a href="index.php"> Home page </a><br>

    <p>Find:</p>
    <ul>
        <li><a href="find_phone.php"> Phone </a></li>
        <li><a href="find_partner.php"> Partner </a></li>
    </ul>
</body>
</html>